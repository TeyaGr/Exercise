
public class For {
public static void main(String[] args) {
	
	int [] arr = {3,10,14,15,40,77,80};
	
	for (int a=0; a<arr.length; a++) {
		if (arr[a]%5==0) {
			System.out.println(arr[a]);
		}
	}
		
}
}
