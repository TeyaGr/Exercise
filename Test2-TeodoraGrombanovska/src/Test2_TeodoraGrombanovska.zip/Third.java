import java.util.HashMap;
import java.util.Scanner;

public class Third {
public static void main(String[] args) {
	
	Integer [] array =  {1, 7, 4, 3, 4, 8, 7};
	HashMap<Integer,Integer> h = new HashMap<Integer,Integer>();
	h.put(1, 1);
	h.put(7, 2);
	h.put(4, 2);
	h.put(3, 1);
	h.put(8, 1);
	Scanner scan = new Scanner(System.in);
	int i = scan.nextInt();
	
}
}
