import java.util.LinkedList;
import java.util.Scanner;
import java.util.Stack;

public class Second {
public static void main(String[] args) {
	
	int[] array = {2,5,8,3,4,5,6,1};
	Scanner scan = new Scanner(System.in);
	Stack<Integer> q = new Stack <>();
	LinkedList <Integer> list= new LinkedList<>();
//	System.out.println("Enter the number you want to check on:");
	int n = scan.nextInt();
	for(Integer i:array) {
		list.addLast(i);
		while(!list.isEmpty()) {
			if(list.get(n)<list.getFirst()) {
				System.out.println(list.getFirst());
			}
		}
		}
		
}
	
}

	



