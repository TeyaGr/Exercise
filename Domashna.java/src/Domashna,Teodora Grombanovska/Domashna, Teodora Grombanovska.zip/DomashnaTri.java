
public class DomashnaTri {
	public static void main(String[] args) {
		
		String str="Hello students! How is the weather today?";
		
		System.out.println(str.length());
		System.out.println(str.indexOf("?"));
		System.out.println(str.substring(16));
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		System.out.println(str.lastIndexOf("d"));
		System.out.println(str.replace("Hello", "Hey"));
		
		
		
		
	
	}
}

	
