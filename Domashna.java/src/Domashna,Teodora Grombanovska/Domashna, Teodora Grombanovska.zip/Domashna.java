
public class Domashna {

	public static void main(String[] args) {
		
		int a;
		a=358;
		int kvadrat = a*a;
		
		System.out.println("a na kvadrat =" + kvadrat);
		
		
	}
}
